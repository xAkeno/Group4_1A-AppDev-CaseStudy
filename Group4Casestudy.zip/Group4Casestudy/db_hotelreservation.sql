-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2024 at 01:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hotelreservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `answer` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `firstname`, `lastname`, `email`, `answer`, `username`, `password`) VALUES
(10000, 'admin', 'admin', 'admin', 'admin', 'admin', 'admin'),
(10001, 'mars', 'toms', 'mars@gmail.com', 'wilber', 'mike', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `addonsdetails`
--

CREATE TABLE `addonsdetails` (
  `addonsID` int(11) NOT NULL,
  `price` varchar(20) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `reserve_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addonsdetails`
--

INSERT INTO `addonsdetails` (`addonsID`, `price`, `account_id`, `reserve_id`) VALUES
(1, '650', 10000, 5000),
(2, '250', 10000, 5000),
(3, '650', 10000, 5000),
(2000, '100.00', NULL, 5018),
(2001, '100.00', NULL, 5018),
(2002, '100.00', NULL, 5018),
(2003, '100.00', NULL, 5018),
(2004, '100.00', NULL, 5018),
(2005, '650', NULL, 5018),
(2006, '650', NULL, 5018),
(2007, '650', NULL, 5018),
(2008, '650', NULL, 5018),
(2009, '650', 10000, 5000),
(2010, '650', 10000, 5000),
(2011, '650', 10000, 5000),
(2012, '300', 10000, 5000),
(2013, '500', 10000, 5000),
(2014, '500', 10000, 5000),
(2015, '650', 10000, 5000),
(2016, '650', 10000, 5000),
(2017, '650', 10000, 5000),
(2018, '650', 10000, 5000),
(2019, '650', 10000, 5000),
(2020, '100', 10000, 5000),
(2021, '100', 10000, 5000),
(2022, '650', 10000, 5000),
(2023, '250', 10000, 5000),
(2024, '100', 10000, 5000),
(2025, '100', 10000, 5000),
(2026, '100', 10000, 5000),
(2027, '100', 10000, 5000),
(2028, '100', 10000, 5000),
(2029, '650', 10000, 5000),
(2030, '650', 10000, 5000),
(2031, '650', 10000, 5000),
(2032, '100', 10000, 5000),
(2033, '100', 10000, 5000),
(2034, '100', 10000, 5000),
(2035, '650', 10000, 5000),
(2036, '650', 10000, 5000),
(2037, '650', 10000, 5000),
(2038, '650', 10000, 5000),
(2039, '650', 10000, 5000),
(2040, '650', 10000, 5000),
(2041, '650', 10000, 5000),
(2042, '650', 10000, 5000),
(2043, '100', 10000, 5000),
(2044, '100', 10000, 5000),
(2045, '100', 10000, 5000),
(2046, '100', 10000, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `addonsinfo`
--

CREATE TABLE `addonsinfo` (
  `addons_CODE` varchar(4) NOT NULL,
  `item` varchar(10) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addonsinfo`
--

INSERT INTO `addonsinfo` (`addons_CODE`, `item`, `price`) VALUES
('AA1', 'BED', 650),
('AA2', 'BLANKET', 250),
('AA3', 'Pillow', 100),
('AA4', 'Toiletries', 200);

-- --------------------------------------------------------

--
-- Table structure for table `amenitiesinfo`
--

CREATE TABLE `amenitiesinfo` (
  `amen_CODE` varchar(3) NOT NULL,
  `item` varchar(10) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `amenitiesinfo`
--

INSERT INTO `amenitiesinfo` (`amen_CODE`, `item`, `price`) VALUES
('AM1', 'Swimming p', '300'),
('AM2', 'gym', '500'),
('AM3', 'foot spa', '825'),
('AM4', 'aroma faci', '1045'),
('AM5', 'thai massa', '1540');

-- --------------------------------------------------------

--
-- Table structure for table `ammenitiesdetails`
--

CREATE TABLE `ammenitiesdetails` (
  `ammentiesID` int(11) NOT NULL,
  `price` varchar(20) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `reserve_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ammenitiesdetails`
--

INSERT INTO `ammenitiesdetails` (`ammentiesID`, `price`, `account_id`, `reserve_id`) VALUES
(20000, '300', 10000, 5000),
(20001, '300', 10000, 5000),
(20002, '300', 10000, 5000),
(20003, '500', 10000, 5000),
(20004, '500', 10000, 5000),
(20005, '300', 10000, 5000),
(20006, '300', 10000, 5000),
(20007, '300', 10000, 5000),
(20008, '300', 10000, 5000),
(20009, '300', 10000, 5000),
(20010, '300', 10000, 5000),
(20011, '300', 10000, 5000),
(20012, '825', 10000, 5000),
(20013, '825', 10000, 5000),
(20014, '825', 10000, 5000),
(20015, '825', 10000, 5000),
(20016, '300', 10000, 5000),
(20017, '300', 10000, 5000),
(20018, '500', 10000, 5000),
(20019, '500', 10000, 5000),
(20020, '825', 10000, 5000),
(20021, '825', 10000, 5000),
(20022, '825', 10000, 5000),
(20023, '1045', 10000, 5000),
(20024, '1045', 10000, 5000),
(20025, '1045', 10000, 5000),
(20026, '1045', 10000, 5000),
(20027, '1540', 10000, 5000),
(20028, '1540', 10000, 5000),
(20029, '1540', 10000, 5000),
(20030, '1540', 10000, 5000),
(20031, '1540', 10000, 5000),
(20032, '500', 10000, 5000),
(20033, '500', 10000, 5000),
(20034, '500', 10000, 5000),
(20035, '1540', 10000, 5000),
(20036, '1540', 10000, 5000),
(20037, '300', 10000, 5000),
(20038, '300', 10000, 5000),
(20039, '300', 10000, 5000),
(20040, '825', 10000, 5000),
(20041, '825', 10000, 5000),
(20042, '825', 10000, 5000),
(20043, '500', 10000, 5000),
(20044, '500', 10000, 5000),
(20045, '500', 10000, 5000),
(20046, '500', 10000, 5000),
(20047, '300', 10000, 5000),
(20048, '300', 10000, 5000),
(20049, '300', 10000, 5000),
(20050, '300', 10000, 5000),
(20051, '300', 10000, 5000),
(20052, '300', 10000, 5000),
(20053, '300', 10000, 5000),
(20054, '300', 10000, 5000),
(20055, '300', 10000, 5000),
(20056, '300', 10000, 5000),
(20057, '300', 10000, 5000),
(20058, '300', 10000, 5000),
(20059, '300', 10000, 5000),
(20060, '300', 10000, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `destination` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`destination`) VALUES
('International'),
('Local');

-- --------------------------------------------------------

--
-- Table structure for table `guestdetails`
--

CREATE TABLE `guestdetails` (
  `guest_id` int(11) NOT NULL,
  `child` varchar(20) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `reserve_id` int(11) DEFAULT NULL,
  `Pw_Elder` varchar(20) DEFAULT NULL,
  `adults` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guestdetails`
--

INSERT INTO `guestdetails` (`guest_id`, `child`, `account_id`, `reserve_id`, `Pw_Elder`, `adults`) VALUES
(3000, '2', NULL, NULL, 'YES', '3'),
(3001, '0', NULL, NULL, 'No', '2'),
(3002, '0', 10000, 5000, 'YES', '3'),
(3003, '0', 10000, 5000, 'YES', '2'),
(3004, '0', 10000, 5000, 'No', '2'),
(3005, '0', 10000, 5000, 'No', '1'),
(3006, '0', 10000, 5000, 'No', '2'),
(3007, '0', 10000, 5000, 'No', '1'),
(3008, '0', 10000, 5000, 'No', '1'),
(3009, '0', NULL, NULL, 'No', '1'),
(3010, '0', NULL, NULL, 'YES', '1'),
(3011, '0', NULL, 5012, 'No', '2'),
(3012, '1', NULL, 5013, 'YES', '3'),
(3013, '0', NULL, 5014, 'No', '2'),
(3014, '1', NULL, 5015, 'YES', '3'),
(3015, '0', NULL, 5016, 'No', '1'),
(3016, '0', NULL, 5017, 'No', '1'),
(3017, '0', NULL, 5018, 'No', '1'),
(3018, '0', NULL, 5019, 'No', '1'),
(3019, '0', NULL, 5020, 'No', '1'),
(3020, '0', NULL, 5021, 'No', '1'),
(3021, '0', NULL, 5022, 'No', '2'),
(3022, '0', 10000, 5023, 'No', '1'),
(3023, '0', 10000, 5024, 'No', '1'),
(3024, '0', 10000, 5025, 'No', '1'),
(3025, '0', 10000, 5026, 'No', '1'),
(3026, '0', 10000, 5027, 'No', '1'),
(3027, '0', 10000, NULL, 'No', '1'),
(3028, '0', 10000, NULL, 'No', '1'),
(3029, '0', 10000, NULL, 'No', '1'),
(3030, '0', 10000, NULL, 'No', '1'),
(3031, '0', 10000, NULL, 'No', '1'),
(3032, '0', 10000, NULL, 'No', '1'),
(3033, '0', 10000, NULL, 'No', '1'),
(3034, '0', 10000, NULL, 'No', '1'),
(3035, '0', 10000, NULL, 'No', '1'),
(3036, '0', 10000, NULL, 'No', '1'),
(3037, '0', 10000, NULL, 'No', '1'),
(3038, '0', 10000, NULL, 'No', '1'),
(3039, '0', 10000, NULL, 'No', '1'),
(3040, '0', 10000, NULL, 'No', '1'),
(3041, '0', 10000, NULL, 'No', '2'),
(3042, '0', 10000, NULL, 'No', '1'),
(3043, '0', 10000, NULL, 'No', '1'),
(3044, '0', 10000, NULL, 'No', '1'),
(3045, '0', 10000, NULL, 'No', '1'),
(3046, '0', 10000, NULL, 'No', '1'),
(3047, '0', 10000, NULL, 'No', '1'),
(3048, '0', 10000, NULL, 'No', '1'),
(3049, '0', 10000, NULL, 'No', '1'),
(3050, '0', 10000, NULL, 'No', '1'),
(3051, '0', 10000, NULL, 'No', '1'),
(3052, '0', 10000, NULL, 'No', '1'),
(3053, '0', 10000, NULL, 'No', '1'),
(3054, '1', 10000, NULL, 'YES', '2'),
(3055, '0', 10000, NULL, 'No', '1'),
(3056, '0', 10000, NULL, 'No', '1'),
(3057, '0', 10000, NULL, 'No', '1'),
(3058, '0', 10000, NULL, 'No', '1'),
(3059, '0', 10000, NULL, 'No', '1'),
(3060, '0', 10000, NULL, 'No', '1'),
(3061, '0', 10000, NULL, 'No', '1'),
(3062, '0', 10000, NULL, 'No', '1'),
(3063, '0', 10000, NULL, 'No', '1'),
(3064, '0', 10000, NULL, 'No', '1'),
(3065, '0', 10000, NULL, 'No', '1'),
(3066, '0', 10000, NULL, 'No', '1'),
(3067, '0', 10000, NULL, 'No', '1'),
(3068, '0', 10000, NULL, 'No', '1'),
(3069, '0', 10000, NULL, 'No', '1'),
(3070, '0', 10000, NULL, 'No', '1'),
(3071, '0', 10000, NULL, 'No', '1'),
(3072, '0', 10000, NULL, 'No', '1'),
(3073, '0', 10000, NULL, 'No', '1'),
(3074, '0', 10000, NULL, 'No', '1'),
(3075, '0', 10000, NULL, 'No', '1'),
(3076, '0', 10000, NULL, 'No', '1'),
(3077, '0', 10000, NULL, 'No', '1'),
(3078, '0', 10000, NULL, 'No', '1'),
(3079, '0', 10000, NULL, 'No', '1'),
(3080, '0', 10000, NULL, 'No', '1'),
(3081, '0', 10000, NULL, 'No', '1'),
(3082, '0', 10000, NULL, 'No', '5'),
(3083, '0', 10000, NULL, 'No', '1'),
(3084, '0', 10000, NULL, 'No', '1'),
(3085, '0', 10000, NULL, 'No', '1'),
(3086, '0', 10000, NULL, 'No', '1'),
(3087, '0', 10000, NULL, 'No', '1'),
(3088, '0', 10000, NULL, 'No', '1'),
(3089, '0', 10000, NULL, 'No', '1'),
(3090, '0', 10000, NULL, 'No', '1'),
(3091, '0', 10000, NULL, 'No', '1'),
(3092, '0', 10000, NULL, 'No', '1'),
(3093, '0', 10000, NULL, 'No', '1'),
(3094, '0', 10000, NULL, 'No', '1'),
(3095, '0', 10000, NULL, 'No', '1'),
(3096, '0', 10000, NULL, 'YES', '2'),
(3097, '0', 10000, NULL, 'No', '2'),
(3098, '0', 10000, NULL, 'No', '3'),
(3099, '0', 10000, NULL, 'No', '1'),
(3100, '0', 10000, NULL, 'No', '1'),
(3101, '0', 10000, NULL, 'No', '1'),
(3102, '0', 10000, NULL, 'No', '1'),
(3103, '0', 10000, NULL, 'No', '1'),
(3104, '0', 10000, NULL, 'No', '1'),
(3105, '2', 10000, NULL, 'No', '3'),
(3106, '2', 10000, NULL, 'No', '3'),
(3107, '0', 10000, NULL, 'YES', '1');

-- --------------------------------------------------------

--
-- Table structure for table `paymentdetails`
--

CREATE TABLE `paymentdetails` (
  `card_no` varchar(20) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `reserve_id` int(11) DEFAULT NULL,
  `payment_method` varchar(20) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rateinfo`
--

CREATE TABLE `rateinfo` (
  `rateID` varchar(20) NOT NULL,
  `season_ID` varchar(20) DEFAULT NULL,
  `roomtype_ID` varchar(20) DEFAULT NULL,
  `destination` varchar(20) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rateinfo`
--

INSERT INTO `rateinfo` (`rateID`, `season_ID`, `roomtype_ID`, `destination`, `price`) VALUES
('RT01', 'SS1', 'Standard', 'Local', 2000),
('RT02', 'SS1', 'Deluxe', 'Local', 3000),
('RT03', 'SS1', 'Quadruple', 'Local', 4000),
('RT04', 'SS1', 'Family', 'Local', 5000),
('RT05', 'SS1', 'Suite', 'Local', 6000),
('RT06', 'SS2', 'Standard', 'Local', 4000),
('RT07', 'SS2', 'Deluxe', 'Local', 5000),
('RT08', 'SS2', 'Quadruple', 'Local', 7000),
('RT09', 'SS2', 'Family', 'Local', 9000),
('RT10', 'SS2', 'Suite', 'Local', 11000),
('RT11', 'SS3', 'Standard', 'Local', 6000),
('RT12', 'SS3', 'Deluxe', 'Local', 8000),
('RT13', 'SS3', 'Quadruple', 'Local', 10000),
('RT14', 'SS3', 'Family', 'Local', 12000),
('RT15', 'SS3', 'Suite', 'Local', 14000),
('RT16', 'SS4', 'Standard', 'Local', 9000),
('RT17', 'SS4', 'Deluxe', 'Local', 12000),
('RT18', 'SS4', 'Quadruple', 'Local', 15000),
('RT19', 'SS4', 'Family', 'Local', 18000),
('RT20', 'SS4', 'Suite', 'Local', 21000),
('RT21', 'SS1', 'Standard', 'International', 2500),
('RT22', 'SS1', 'Deluxe', 'International', 5000),
('RT23', 'SS1', 'Quadruple', 'International', 7500),
('RT24', 'SS1', 'Family', 'International', 10000),
('RT25', 'SS1', 'Suite', 'International', 12000),
('RT26', 'SS2', 'Standard', 'International', 4500),
('RT27', 'SS2', 'Deluxe', 'International', 7000),
('RT28', 'SS2', 'Quadruple', 'International', 9500),
('RT29', 'SS2', 'Family', 'International', 12000),
('RT30', 'SS2', 'Suite', 'International', 14500),
('RT31', 'SS3', 'Standard', 'International', 6500),
('RT32', 'SS3', 'Deluxe', 'International', 9000),
('RT33', 'SS3', 'Quadruple', 'International', 11500),
('RT34', 'SS3', 'Family', 'International', 14000),
('RT35', 'SS3', 'Suite', 'International', 16500),
('RT36', 'SS4', 'Standard', 'International', 10000),
('RT37', 'SS4', 'Deluxe', 'International', 13000),
('RT38', 'SS4', 'Quadruple', 'International', 16000),
('RT39', 'SS4', 'Family', 'International', 19000),
('RT40', 'SS4', 'Suite', 'International', 22000);

-- --------------------------------------------------------

--
-- Table structure for table `reservationdetails`
--

CREATE TABLE `reservationdetails` (
  `reserve_id` int(11) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `check_in` varchar(20) DEFAULT NULL,
  `check_out` varchar(20) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `seasons` varchar(20) DEFAULT NULL,
  `rooms` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservationdetails`
--

INSERT INTO `reservationdetails` (`reserve_id`, `account_id`, `check_in`, `check_out`, `destination`, `seasons`, `rooms`) VALUES
(5000, 10000, 'NA', 'NA', 'NA', 'Peak', 'Quadruple'),
(5001, 10000, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5002, 10000, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5003, 10000, '01/05/2024', '01/09/2024', 'Local', NULL, NULL),
(5004, 10000, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5005, 10000, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5006, 10000, '01/05/2024', '01/09/2024', 'International', NULL, NULL),
(5007, 10000, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5008, 10000, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5009, 10000, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5010, 10000, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5011, 10000, '01/05/2024', '01/10/2024', 'International', NULL, NULL),
(5012, 10000, '01/05/2024', '01/09/2024', 'International', 'Peak', 'Deluxe'),
(5013, 10000, '01/05/2024', '01/11/2024', 'International', 'Peak', 'Family'),
(5014, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Quadruple'),
(5015, 10000, '01/05/2024', '01/08/2024', 'Local', 'Peak', 'Quadruple'),
(5016, 10000, '01/05/2024', '01/09/2024', 'International', 'Peak', 'Deluxe'),
(5017, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5018, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5019, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5020, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5021, NULL, '01/05/2024', '01/06/2024', 'International', NULL, NULL),
(5022, NULL, '01/05/2024', '01/09/2024', 'International', 'Peak', 'Quadruple'),
(5023, NULL, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Quadruple'),
(5024, NULL, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5025, NULL, '01/05/2024', '01/06/2024', 'International', 'Peak', 'Deluxe'),
(5026, NULL, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5027, NULL, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5028, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5029, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5030, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5031, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5032, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5033, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5034, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5035, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5036, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5037, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5038, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5039, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5040, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5041, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5042, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5043, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5044, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5045, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5046, NULL, '01/05/2024', '01/09/2024', 'International', NULL, NULL),
(5047, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5048, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5049, NULL, '01/05/2024', '01/09/2024', 'International', NULL, NULL),
(5050, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5051, NULL, '01/05/2024', '01/10/2024', 'International', NULL, NULL),
(5052, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5053, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5054, NULL, '01/05/2024', '01/09/2024', 'International', NULL, NULL),
(5055, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5056, NULL, '01/05/2024', '01/06/2024', 'International', NULL, NULL),
(5057, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5058, NULL, '01/05/2024', '01/08/2024', 'International', NULL, NULL),
(5059, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5060, NULL, '01/05/2024', '01/07/2024', 'International', NULL, NULL),
(5061, NULL, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5062, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5063, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5064, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5065, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Standard'),
(5066, 10000, '01/05/2024', '01/06/2024', 'International', 'Peak', 'Deluxe'),
(5067, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Deluxe'),
(5068, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5069, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Standard'),
(5070, 10000, '01/05/2024', '01/09/2024', 'International', 'Peak', 'Deluxe'),
(5071, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5072, 10000, '01/05/2024', '01/06/2024', 'International', 'Peak', 'Standard'),
(5073, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5074, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5075, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5076, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Deluxe'),
(5077, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Suite'),
(5078, 10000, '01/05/2024', '01/09/2024', 'International', 'Peak', 'Suite'),
(5079, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Deluxe'),
(5080, 10000, '01/05/2024', '01/07/2024', 'International', 'Peak', 'Deluxe'),
(5081, 10000, '01/05/2024', '01/08/2024', 'International', 'Peak', 'Standard'),
(5082, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Standard'),
(5083, 10000, '01/06/2024', '01/08/2024', 'Local', 'Lean', 'Family'),
(5084, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Deluxe'),
(5085, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Standard'),
(5086, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Standard'),
(5087, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Deluxe'),
(5088, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5089, 10000, '01/06/2024', '01/09/2024', 'International', 'Lean', 'Quadruple'),
(5090, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5091, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Suite'),
(5092, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5093, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Quadruple'),
(5094, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Standard'),
(5095, 10000, '01/06/2024', '01/09/2024', 'International', 'Lean', 'Deluxe'),
(5096, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5097, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5098, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5099, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Quadruple'),
(5100, 10000, '01/06/2024', '01/09/2024', 'International', 'Lean', 'Deluxe'),
(5101, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5102, 10000, '01/06/2024', '04/06/2024', 'International', 'Lean', 'Deluxe'),
(5103, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Standard'),
(5104, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe'),
(5105, 10000, '01/06/2024', '01/07/2024', 'International', NULL, NULL),
(5106, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Quadruple'),
(5107, 10000, '01/06/2024', '01/07/2024', 'International', 'Lean', 'Family'),
(5108, 10000, '01/06/2024', '01/08/2024', 'International', 'Lean', 'Deluxe');

-- --------------------------------------------------------

--
-- Table structure for table `seasondetails`
--

CREATE TABLE `seasondetails` (
  `season_ID` varchar(3) NOT NULL,
  `season` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seasondetails`
--

INSERT INTO `seasondetails` (`season_ID`, `season`) VALUES
('SS1', 'Lean'),
('SS2', 'High'),
('SS3', 'Peak'),
('SS4', 'Supe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `addonsdetails`
--
ALTER TABLE `addonsdetails`
  ADD PRIMARY KEY (`addonsID`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `reserve_id` (`reserve_id`);

--
-- Indexes for table `addonsinfo`
--
ALTER TABLE `addonsinfo`
  ADD PRIMARY KEY (`addons_CODE`);

--
-- Indexes for table `amenitiesinfo`
--
ALTER TABLE `amenitiesinfo`
  ADD PRIMARY KEY (`amen_CODE`);

--
-- Indexes for table `ammenitiesdetails`
--
ALTER TABLE `ammenitiesdetails`
  ADD PRIMARY KEY (`ammentiesID`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `reserve_id` (`reserve_id`);

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`destination`);

--
-- Indexes for table `guestdetails`
--
ALTER TABLE `guestdetails`
  ADD PRIMARY KEY (`guest_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `reserve_id` (`reserve_id`);

--
-- Indexes for table `paymentdetails`
--
ALTER TABLE `paymentdetails`
  ADD PRIMARY KEY (`card_no`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `reserve_id` (`reserve_id`);

--
-- Indexes for table `rateinfo`
--
ALTER TABLE `rateinfo`
  ADD PRIMARY KEY (`rateID`),
  ADD KEY `season_ID` (`season_ID`),
  ADD KEY `destination` (`destination`);

--
-- Indexes for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  ADD PRIMARY KEY (`reserve_id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `seasondetails`
--
ALTER TABLE `seasondetails`
  ADD PRIMARY KEY (`season_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10002;

--
-- AUTO_INCREMENT for table `addonsdetails`
--
ALTER TABLE `addonsdetails`
  MODIFY `addonsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2047;

--
-- AUTO_INCREMENT for table `ammenitiesdetails`
--
ALTER TABLE `ammenitiesdetails`
  MODIFY `ammentiesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20061;

--
-- AUTO_INCREMENT for table `guestdetails`
--
ALTER TABLE `guestdetails`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3108;

--
-- AUTO_INCREMENT for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  MODIFY `reserve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5109;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addonsdetails`
--
ALTER TABLE `addonsdetails`
  ADD CONSTRAINT `addonsdetails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  ADD CONSTRAINT `addonsdetails_ibfk_2` FOREIGN KEY (`reserve_id`) REFERENCES `reservationdetails` (`reserve_id`);

--
-- Constraints for table `ammenitiesdetails`
--
ALTER TABLE `ammenitiesdetails`
  ADD CONSTRAINT `ammenitiesdetails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  ADD CONSTRAINT `ammenitiesdetails_ibfk_2` FOREIGN KEY (`reserve_id`) REFERENCES `reservationdetails` (`reserve_id`);

--
-- Constraints for table `guestdetails`
--
ALTER TABLE `guestdetails`
  ADD CONSTRAINT `guestdetails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  ADD CONSTRAINT `guestdetails_ibfk_2` FOREIGN KEY (`reserve_id`) REFERENCES `reservationdetails` (`reserve_id`);

--
-- Constraints for table `paymentdetails`
--
ALTER TABLE `paymentdetails`
  ADD CONSTRAINT `paymentdetails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  ADD CONSTRAINT `paymentdetails_ibfk_2` FOREIGN KEY (`reserve_id`) REFERENCES `reservationdetails` (`reserve_id`);

--
-- Constraints for table `rateinfo`
--
ALTER TABLE `rateinfo`
  ADD CONSTRAINT `rateinfo_ibfk_1` FOREIGN KEY (`season_ID`) REFERENCES `seasondetails` (`season_ID`),
  ADD CONSTRAINT `rateinfo_ibfk_2` FOREIGN KEY (`destination`) REFERENCES `destination` (`destination`);

--
-- Constraints for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  ADD CONSTRAINT `reservationdetails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
